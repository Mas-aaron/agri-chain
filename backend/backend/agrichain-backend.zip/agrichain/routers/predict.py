from __future__ import annotations

from typing import List, Optional, Union

import pandas as pd
from fastapi import APIRouter, Body, HTTPException
from pydantic import BaseModel

from agrichain.services.model import get_model_name, load_artifacts

router = APIRouter()


class PredictionRequest(BaseModel):
    nitrogen: float
    phosphorus: float
    potassium: float
    temperature: float
    humidity: float
    ph: float
    rainfall: float
    pesticide: float


def _build_feature_row(request: PredictionRequest) -> dict:
    n = float(request.nitrogen)
    p = float(request.phosphorus)
    k = float(request.potassium)
    t = float(request.temperature)
    h = float(request.humidity)
    ph_val = float(request.ph)
    r = float(request.rainfall)
    pest = float(request.pesticide)

    eps = 0.001

    fertilizer_total = n + p + k
    ratio_np = n / (p + eps)
    ratio_nk = n / (k + eps)

    return {
        "Nitrogen": n,
        "Phosphorus": p,
        "Potassium": k,
        "Temperature": t,
        "Humidity": h,
        "pH": ph_val,
        "Rainfall": r,
        "Pesticide": pest,
        "N_P_Interaction": n * p,
        "N_K_Interaction": n * k,
        "P_K_Interaction": p * k,
        "Temp_Rain_Interaction": t * r,
        "N_squared": n**2,
        "P_squared": p**2,
        "K_squared": k**2,
        "Temp_squared": t**2,
        "Rainfall_squared": r**2,
        "Fertilizer_Total": fertilizer_total,
        "Fertilizer_Ratio_NP": ratio_np,
        "Fertilizer_Ratio_NK": ratio_nk,
    }


class PredictionResponse(BaseModel):
    predicted_yield: float
    confidence: Optional[float] = None
    message: Optional[str] = None


class BatchPredictionRequest(BaseModel):
    requests: List[PredictionRequest]


@router.get("/")
async def root():
    try:
        _, preprocessing_info = load_artifacts()
        model_name = get_model_name(preprocessing_info)
        return {
            "message": "Maize Yield Prediction API",
            "model": model_name,
            "r2_score": preprocessing_info.get("best_r2_score"),
            "endpoints": {
                "/predict": "POST - Make single prediction",
                "/batch-predict": "POST - Make batch predictions",
                "/health": "GET - Check API health",
                "/contracts": "GET/POST - List or create future harvest contracts (SQLite demo)",
                "/contracts/{id}/purchase": "POST - Purchase a contract (SQLite demo)",
                "/contracts/{id}/deliver": "POST - Mark a contract delivered (SQLite demo)",
                "/ledger": "GET - List ledger events (SQLite demo)",
            },
        }
    except Exception as e:
        return {
            "message": "Maize Yield Prediction API",
            "model_loaded": False,
            "error": str(e),
            "endpoints": {
                "/predict": "POST - Make single prediction",
                "/batch-predict": "POST - Make batch predictions",
                "/health": "GET - Check API health",
                "/contracts": "GET/POST - List or create future harvest contracts (SQLite demo)",
                "/contracts/{id}/purchase": "POST - Purchase a contract (SQLite demo)",
                "/contracts/{id}/deliver": "POST - Mark a contract delivered (SQLite demo)",
                "/ledger": "GET - List ledger events (SQLite demo)",
            },
        }


@router.get("/health")
async def health_check():
    try:
        load_artifacts()
        return {"status": "healthy", "model_loaded": True}
    except Exception as e:
        return {"status": "healthy", "model_loaded": False, "error": str(e)}


@router.post("/predict", response_model=PredictionResponse)
async def predict_yield(request: PredictionRequest):
    try:
        model, preprocessing_info = load_artifacts()
        model_name = get_model_name(preprocessing_info) or "model"

        data = pd.DataFrame([_build_feature_row(request)])

        feature_names = preprocessing_info["feature_names"]
        data = data[feature_names]

        scaler = preprocessing_info.get("scaler")
        if scaler is not None and hasattr(scaler, "transform"):
            features = scaler.transform(data)
        else:
            features = data

        prediction = model.predict(features)

        return PredictionResponse(
            predicted_yield=float(prediction[0]),
            confidence=None,
            message=f"Prediction successful using {model_name}",
        )

    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/batch-predict")
async def batch_predict_yield(payload: Union[List[PredictionRequest], BatchPredictionRequest] = Body(...)):
    try:
        model, preprocessing_info = load_artifacts()
        model_name = get_model_name(preprocessing_info)

        requests = payload.requests if isinstance(payload, BatchPredictionRequest) else payload

        rows = [_build_feature_row(r) for r in requests]

        data = pd.DataFrame(rows)
        feature_names = preprocessing_info["feature_names"]
        data = data[feature_names]

        scaler = preprocessing_info.get("scaler")
        if scaler is not None and hasattr(scaler, "transform"):
            features = scaler.transform(data)
        else:
            features = data

        preds = model.predict(features)

        predictions = []
        for i, r in enumerate(requests):
            predictions.append(
                {
                    "nitrogen": r.nitrogen,
                    "phosphorus": r.phosphorus,
                    "potassium": r.potassium,
                    "temperature": r.temperature,
                    "humidity": r.humidity,
                    "ph": r.ph,
                    "rainfall": r.rainfall,
                    "pesticide": r.pesticide,
                    "predicted_yield": float(preds[i]),
                }
            )

        return {
            "predictions": predictions,
            "count": len(predictions),
            "model": model_name,
        }

    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
